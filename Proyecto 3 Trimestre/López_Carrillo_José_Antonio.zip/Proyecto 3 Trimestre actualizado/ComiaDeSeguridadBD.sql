-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Versión del servidor:         10.4.12-MariaDB - mariadb.org binary distribution
-- SO del servidor:              Win64
-- HeidiSQL Versión:             10.2.0.5599
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Volcando datos para la tabla tienda.estado_oferta: ~4 rows (aproximadamente)
/*!40000 ALTER TABLE `estado_oferta` DISABLE KEYS */;
INSERT INTO `estado_oferta` (`nombre_tipo_Oferta`) VALUES
	('DENEGADO'),
	('ESPERA'),
	('FINALIZADO'),
	('PROCESANDO');
/*!40000 ALTER TABLE `estado_oferta` ENABLE KEYS */;

-- Volcando datos para la tabla tienda.estado_peticion: ~3 rows (aproximadamente)
/*!40000 ALTER TABLE `estado_peticion` DISABLE KEYS */;
INSERT INTO `estado_peticion` (`nombre_tipo_peticion`) VALUES
	('ESPERA'),
	('FINALIZADO'),
	('PROCESANDO');
/*!40000 ALTER TABLE `estado_peticion` ENABLE KEYS */;

-- Volcando datos para la tabla tienda.oferta: ~10 rows (aproximadamente)
/*!40000 ALTER TABLE `oferta` DISABLE KEYS */;
INSERT INTO `oferta` (`id_Oferta`, `descripccion_Oferta`, `precio_oferta`, `usuario_oferta`, `nombre_tipo_oferta`, `id_Peticion`) VALUES
	(1, 'yo te limpio', 15, '11345678F', 'PROCESANDO', 3),
	(2, 'te limpio perfectamente', 50, '14725836m', 'DENEGADO', 3),
	(3, '', 10, '25836914k', 'DENEGADO', 3),
	(4, '', 20, '12345678A', 'FINALIZADO', 1),
	(5, '', 15, '11345678F', 'ESPERA', 1),
	(6, 'te lo hago barato y rapido', 15, '98765432A', 'ESPERA', 2),
	(7, 'Le ofrezco un salario de 10 euros las hora x una limpieza completa (entorno a 4 horas) ', 10, '12345678A', 'ESPERA', 1),
	(8, 'Te ayudo con tus kehaseres', 3, '22345678G', 'ESPERA', 1),
	(9, 'yo te limpio', 15, '11345678F', 'ESPERA', 1),
	(10, 'ESPERA', 1, '10000000n', 'ESPERA', 1);
/*!40000 ALTER TABLE `oferta` ENABLE KEYS */;

-- Volcando datos para la tabla tienda.peticion: ~4 rows (aproximadamente)
/*!40000 ALTER TABLE `peticion` DISABLE KEYS */;
INSERT INTO `peticion` (`id_Peticion`, `descripccion_Peticion`, `precio_Medio`, `usuario_Peticion`, `id_Oferta`, `nombre_estado_Peticion`) VALUES
	(1, 'necesito que me limpien la casa', 258, '11345678F', 10, 'ESPERA'),
	(2, 'necesito que me limpien toda la oficina', 10, '12345678A', 4, 'FINALIZADO'),
	(3, 'segunda vez here we go', 145, '12345678A', 1, 'PROCESANDO'),
	(4, 'Sexar Pollos', 1, '22345678G', 10, 'ESPERA');
/*!40000 ALTER TABLE `peticion` ENABLE KEYS */;

-- Volcando datos para la tabla tienda.tipo_de_usuario: ~2 rows (aproximadamente)
/*!40000 ALTER TABLE `tipo_de_usuario` DISABLE KEYS */;
INSERT INTO `tipo_de_usuario` (`Nombre_Tipo_Usuario`) VALUES
	('EMPRESARIO'),
	('PARTICULAR');
/*!40000 ALTER TABLE `tipo_de_usuario` ENABLE KEYS */;

-- Volcando datos para la tabla tienda.tipo_de_usuario_valorado: ~2 rows (aproximadamente)
/*!40000 ALTER TABLE `tipo_de_usuario_valorado` DISABLE KEYS */;
INSERT INTO `tipo_de_usuario_valorado` (`Nombre_Tipo_Usuario_Valorado`) VALUES
	('EMPRESARIO'),
	('PARTICULAR');
/*!40000 ALTER TABLE `tipo_de_usuario_valorado` ENABLE KEYS */;

-- Volcando datos para la tabla tienda.usuario: ~12 rows (aproximadamente)
/*!40000 ALTER TABLE `usuario` DISABLE KEYS */;
INSERT INTO `usuario` (`dni_nif`, `nombre`, `contraseña`, `fecha_de_nacimiento`, `correo_Electronico`, `telefono`, `direccion`, `descripcion`, `nombre_tipo_de_usuario`) VALUES
	('10000000n', 'Esperando', 'Esperando123', '1990-01-01', 'example@example.com', 111111111, 'nada', 'en espera', 'EMPRESARIO'),
	('11345678F', 'Alvaro', 'contraseña123', '2020-05-12', 'Alvaro@gmail.com', 959314739, 'Calle cine victoria n3', 'x', 'EMPRESARIO'),
	('12345678A', 'Jose lopez', 'contraseña123', '2020-05-12', 'josanloca@gmail.com', 959331739, 'Calle cine victoria n2', 'x', 'PARTICULAR'),
	('13345678D', 'Manuela', 'contraseña123', '2020-05-12', 'Manuela@gmail.com', 959211739, 'Calle cine victoria n4', 'x', 'EMPRESARIO'),
	('14725836m', 'kololo', 'contraseña123', '1996-07-24', 'josanlocaca@gmail.com', 959331425, 'null', 'jolin', 'PARTICULAR'),
	('15912395V', 'pepe', '50ccfe1a04db8526dfe34107286c9b77bfa1227c18289b98345de03a9268b402761b428bd5dd2768c3898d166d49516dfae9f82d34c191e49c7c41657c1517c', '2013-04-21', 'LOLO@gmail.com', 959331733, 'Calle cine Victoria n15', 'x', 'EMPRESARIO'),
	('15917895l', 'Jose lopez', 'contraseña123', '2013-04-21', '154@gmail.com', 959331731, 'Calle cine victoria n2', 'X', 'PARTICULAR'),
	('15947895b', 'Jose lopez', 'contraseña123', '2013-04-21', 'xxxx@gmail.com', 959333333, 'Calle cine victoria n2', 'x', 'PARTICULAR'),
	('22345678G', 'jesus', '1234567', '2020-05-12', 'jesus@gmail.com', 959331987, 'Calle cine victoria n3', 'x', 'PARTICULAR'),
	('25836914k', 'pablete', 'contraseña123', '1996-07-24', 'josanlocacoca@gmail.com', 959337845, 'null', 'nope', 'PARTICULAR'),
	('98765432A', 'pepe', '50ccfe1a04db8526dfe34107286c9b77bfa1227c18289b98345de03a9268b402761b428bd5dd2768c3898d166d49516dfae9f82d34c191e49c7c41657c1517c', '2013-04-21', 'cacac@gmail.com', 959212425, 'Calle cine Victoria n15', 'x', 'PARTICULAR'),
	('98765432B', 'pepe', '50ccfe1a04db8526dfe34107286c9b77bfa1227c18289b98345de03a9268b402761b428bd5dd2768c3898d166d49516dfae9f82d34c191e49c7c41657c1517c', '1995-07-22', 'cacacOTA@gmail.com', 959211725, 'Calle cine Victoria n15', 'x', 'PARTICULAR');
/*!40000 ALTER TABLE `usuario` ENABLE KEYS */;

-- Volcando datos para la tabla tienda.valoracion: ~7 rows (aproximadamente)
/*!40000 ALTER TABLE `valoracion` DISABLE KEYS */;
INSERT INTO `valoracion` (`id_valoracion`, `puntacion`, `descripccion_valoracion`, `id_Peticion`, `nombre_estado_Peticion`) VALUES
	(1, 10, 'Todo ha sido perfecto', 1, 'PARTICULAR'),
	(2, 7, 'Se ha dejado ciertas zonas sin limpiar', 1, 'EMPRESARIO'),
	(3, 3, 'mhe', 2, 'PARTICULAR'),
	(4, 5, 'decente pero nada del otro mundo', 2, 'EMPRESARIO'),
	(5, 5, 'mediamente normal', 2, 'EMPRESARIO'),
	(6, 5, 'estuvo bastante bien', 2, 'PARTICULAR'),
	(7, 10, 'Ha realizado un trabajo maravilloso', 2, 'PARTICULAR');
/*!40000 ALTER TABLE `valoracion` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
